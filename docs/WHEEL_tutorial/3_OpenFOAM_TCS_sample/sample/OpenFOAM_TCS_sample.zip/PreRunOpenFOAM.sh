#!/bin/bash
#PJM -L "rscgrp=ito-g-1-dbg"
#PJM -L "rscunit=ito-b"
#PJM -L "elapse=1:00:00"
#PJM -j -X -S

source /etc/bashrc
tar xvzf cavity.tar.gz
mv cavity ${WORK}
cd ${WORK}
blockMesh
decomposePar