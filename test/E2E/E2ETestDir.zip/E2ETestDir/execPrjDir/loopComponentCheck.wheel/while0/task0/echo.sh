#!/bin/sh
echo "while test"