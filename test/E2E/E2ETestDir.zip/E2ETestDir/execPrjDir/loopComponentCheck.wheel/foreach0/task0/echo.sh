#!/bin/sh
echo "foreach test" $WHEEL_CURRENT_INDEX