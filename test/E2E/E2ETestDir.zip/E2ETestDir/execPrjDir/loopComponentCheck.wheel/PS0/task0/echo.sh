#!/bin/sh
echo "ps test"