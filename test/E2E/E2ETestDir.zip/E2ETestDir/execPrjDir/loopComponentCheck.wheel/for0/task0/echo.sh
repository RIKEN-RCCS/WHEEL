#!/bin/sh
echo "for test" $WHEEL_CURRENT_INDEX