#!/bin/sh
touch test_1.txt
touch test_2.txt