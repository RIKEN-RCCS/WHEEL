#!/bin/bash
echo test
exit 0