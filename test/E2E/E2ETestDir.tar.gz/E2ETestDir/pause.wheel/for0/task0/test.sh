#!/bin/bash
echo loop $WHEEL_CURRENT_INDEX
exit 0