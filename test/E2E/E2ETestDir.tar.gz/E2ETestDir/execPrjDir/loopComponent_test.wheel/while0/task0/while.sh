#!/bin/sh
echo "while test" $WHEEL_CURRENT_INDEX