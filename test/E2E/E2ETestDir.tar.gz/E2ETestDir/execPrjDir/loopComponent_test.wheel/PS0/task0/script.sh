#!/bin/bash
echo ps test
exit 0