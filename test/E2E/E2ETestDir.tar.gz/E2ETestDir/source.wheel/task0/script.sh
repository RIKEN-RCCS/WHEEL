#!/bin/bash
cat dataA
cat dataB