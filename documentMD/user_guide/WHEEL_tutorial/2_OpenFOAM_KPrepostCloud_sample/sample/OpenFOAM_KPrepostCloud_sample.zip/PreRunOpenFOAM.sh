#!/bin/bash
tar xvzf cavity.tar.gz
mkdir ../WORK
mv cavity ../WORK
cd ../WORK/cavity
blockMesh