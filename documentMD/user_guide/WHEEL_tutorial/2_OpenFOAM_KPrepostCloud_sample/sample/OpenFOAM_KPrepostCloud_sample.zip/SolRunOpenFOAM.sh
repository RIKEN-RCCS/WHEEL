#!/bin/bash
cd ../WORK/cavity
icoFoam > ./log.icoFoam 2>&1