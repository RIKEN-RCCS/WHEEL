#!/bin/bash
cd ../WORK/cavity 
touch result.foam  
cd ../
tar cvzf cavity.tar.gz cavity
mv cavity.tar.gz ../ResultRunOpenFOAM_Task/
