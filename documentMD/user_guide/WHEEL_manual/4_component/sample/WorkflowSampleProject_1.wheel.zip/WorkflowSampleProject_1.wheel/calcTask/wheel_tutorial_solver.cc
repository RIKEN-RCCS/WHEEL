#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <string>
#include <sstream>
#include <iostream>

typedef struct {
	double x;
	double y;
	double z;
} Vec3d;

typedef struct {
	std::vector<Vec3d> vPos;
} stVecters;

Vec3d outer_product(Vec3d pos1, Vec3d pos2)
{
	Vec3d outerProduct;
	outerProduct.x = pos1.y * pos2.z - pos1.z * pos2.y;
	outerProduct.y = pos1.z * pos2.x - pos1.x * pos2.z;
	outerProduct.z = pos1.x * pos2.y - pos1.y * pos2.x;

	return outerProduct;
}

double calc_triangle_area(Vec3d posA, Vec3d posB, Vec3d posC)
{
	Vec3d vecAB, vecAC;
	vecAB.x = posB.x - posA.x;
	vecAB.y = posB.y - posA.y;
	vecAB.z = posB.z - posA.z;
	vecAC.x = posC.x - posA.x;
	vecAC.y = posC.y - posA.y;
	vecAC.z = posC.z - posA.z;

	Vec3d outerProduct;
	outerProduct = outer_product(vecAB, vecAC);

	double absOuterProduct;
	absOuterProduct = sqrt(outerProduct.x * outerProduct.x + outerProduct.y * outerProduct.y + outerProduct.z * outerProduct.z);

	double triangleArea;
	triangleArea = 0.5 * absOuterProduct;

	return triangleArea;
}

void output_result_file(double triangleArea)
{
	FILE* fp = fopen("result.txt", "w");

	fprintf(fp, "result=%g\n", triangleArea);

	fprintf(stdout, "result=%g\n", triangleArea);

	fclose(fp);
}

void import_data_file(stVecters &stPos)
{
	char cbuff[256];
	std::stringstream ss;
	std::string sbuff;
	Vec3d pos;
	std::vector<Vec3d> vPos;
	FILE *fp = fopen("inputdata.txt", "r");

	while (fgets(cbuff, sizeof(cbuff), fp) != NULL)
	{
		ss.clear();
		ss << cbuff;
		std::getline(ss, sbuff, ',');
		pos.x = strtod(sbuff.c_str(), NULL);
		std::getline(ss, sbuff, ',');
		pos.y = strtod(sbuff.c_str(), NULL);
		std::getline(ss, sbuff, ',');
		pos.z = strtod(sbuff.c_str(), NULL);
		vPos.push_back(pos);
	}

	for (int i = 0; i < 3; i++)
	{
		stPos.vPos.push_back(vPos[i]);
	}
}

int main()
{
	stVecters stPos;
	import_data_file(stPos);

	double value;
	value = calc_triangle_area(stPos.vPos[0], stPos.vPos[1], stPos.vPos[2]);

	output_result_file(value);
	return 0;
}
