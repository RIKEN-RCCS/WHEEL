#!/bin/bash
#$ -l rt_F=1
#$ -j y
#$ -cwd

mv kerasMnist.py kerasMnistEval.py /${WORK}
cd /${WORK}
source /etc/profile.d/modules.sh
module load singularity/2.6.1
singularity pull docker://nvcr.io/nvidia/tensorflow:19.06-py2
