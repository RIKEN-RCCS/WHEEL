#!/bin/bash
#$ -l rt_F=1
#$ -j y
#$ -cwd

cd ${WORK}
source /etc/profile.d/modules.sh
module load singularity/2.6.1
singularity run --nv tensorflow-19.06-py2.simg python kerasMnist.py > ./log.kerasMnist 2>&1